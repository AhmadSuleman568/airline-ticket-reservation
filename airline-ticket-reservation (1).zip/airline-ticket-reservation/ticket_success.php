<?php
	session_start();
?>
<html>
	<head>
		<title>
			Ticket Booking Successful
		</title>
		<link rel="stylesheet" type="text/css" href="css/style.css"/>
		<link rel="stylesheet" href="font-awesome-4.7.0\css\font-awesome.min.css">
		<style>
			.airline_header{
	width: 100%; 
	height: 70px;
	background: #65CDAA;
	border: none;
	position: fixed;
	left: 0;
	top: 0;
}
.airline_ul {
list-style-type: none;
margin: 0;
margin-top: 10px;
padding: 0;
overflow: hidden;
background: none;
text-align: center;
}
.airline_ul li{
display: inline;
float: right;
font-size: 1.1em;
}
.airline_ul li a{
display: block;
color: white;
text-align: center;
text-decoration: none;
}
.airline_ul:nth-child(1){
margin-right: 20px;
}
.airline_ul li a:hover {
background-color: #E7E7F6;
color: #030337;
border-radius: 30px;
}
		</style>
	</head>
	<body>
		<div class="airline_header">
			<ul class="airline_ul">
			<li><a href="logout_handler.php">Logout</a></li>
				<li><a href="customer_homepage.php">Contact Us</a></li>
				<li><a href="customer_homepage.php">About Us</a></li>
				<li><a href="pnr.php">Print Ticket</a></li>
				<li><a href="customer_homepage.php">Dashboard</a></li>
				<li><a href="customer_homepage.php">Home</a></li>
			</ul>
		</div>
		<h2 style="margin-top: 100px;">BOOKING SUCCESSFUL</h2>
		<h3>Your payment of &#x20b9; <?php echo $_SESSION['total_amount']; ?> has been received.<br><br> Your PNR is <strong><?php echo $_SESSION['pnr'];?></strong>. Your tickets have been booked successfully.</h3>
	</body>
</html>