<?php
session_start();

$con=mysqli_connect("localhost","root","","airline_reservation");
if(!isset($con))
{
    die("Database Not Found");
}


if(isset($_REQUEST["u_sub"]))
{
    
 $id=$_POST['pnr'];

 if($id!='')
 {
   $query=mysqli_query($con ,"select * from passengers where pnr='".$id."'");
   $res=mysqli_fetch_row($query);
   $query0=mysqli_query($con ,"select * from ticket_details where pnr='".$id."'");
   $res0=mysqli_fetch_row($query0);
   $query1=mysqli_query($con ,"select * from payment_details where pnr='".$id."'");
   $res1=mysqli_fetch_row($query1);

   if($res)
   {
    $_SESSION['user']=$id;
    header('location:pnrcheck.php');
   }
   else
   {
    
    echo '<script>';
    echo 'alert("Invalid username or password")';
    echo '</script>';
   }
if($res0)
   {
    $_SESSION['user']=$id;
    header('location:pnrcheck.php');
   }
   else
   {
    
    echo '<script>';
    echo 'alert("Invalid username or password")';
    echo '</script>';
   }


   
   if($res1)
   {
    $_SESSION['user']=$id;
    header('location:pnrcheck.php');
   }
   else
   {
    
    echo '<script>';
    echo 'alert("Invalid username or password")';
    echo '</script>';
   }
  }
 else
 {
     echo '<script>';
    echo 'alert("Enter both username and password")';
    echo '</script>';
 
 }
}
?>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link type="text/css" rel="stylesheet" href="css/login.css"></link>
        <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
         <link rel="stylesheet" href="bootstrap/bootstrap-theme.min.css">
       <script src="bootstrap/jquery.min.js"></script>
        <script src="bootstrap/bootstrap.min.js"></script>

       
        <title></title>        
        <style>
            
/* form */
.float_form{
width: 25%;
height: auto;
margin: auto;
margin-top: 100px;
float: none;
border: 2px solid #808080;
border-radius: 10px;
padding: 2%;
margin-left: 35%;
}
.float_form input,.float_form select,.bckbtn{
width: 100%;
height: 50px;
border: 1px solid #65CDAA;
outline: none;
margin-top: 10px;
border-radius: 5px;
padding-left: 5%;
}
.float_form input[type="radio"]{
height: 20px;
}
.float_form input[type="submit"],.bckbtn{
padding-left: 0;
font-size: 1.2em;
font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
border: none;
outline: none;
background: #65CDAA;
color: #fff;
}
/* /// */

        </style>
        
    </head>
    <body>
        <form id="index" class="float_form" action="pnr.php" method="post">            
            <div class="container-fluid">    
                <div class="row">
                 </div>    
                <div  id="divtop">
                    <center>
                            <div id="dmain"> 
                                    <input type="text" id="u_id" name="pnr" class="form-control" placeholder="Enter Your PNR Number">
                                    <input type="submit" id="u_sub" name="u_sub" value="Print" class="toggle btn btn-primary">
                                    <button type="button" onclick="location.href = './customer_homepage.php';" class="bckbtn">Back to Portal</button>
                                    <br>
                             </div>
                     </div>
                    </div>
               </div>
            </div>  
            </div>
        </form>  
       </body>
</html>
