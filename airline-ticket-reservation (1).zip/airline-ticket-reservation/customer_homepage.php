<?php
	session_start();
?>
<html>
	<head>
		<title>
			Welcome Customer
		</title>
		<link rel="stylesheet" type="text/css" href="css/style.css"/>
		<link rel="stylesheet" href="font-awesome-4.7.0\css\font-awesome.min.css">
		<style>
			.airline_header{
	width: 100%; 
	height: 70px;
	background: #65CDAA;
	border: none;
	position: fixed;
	left: 0;
	top: 0;
}
.airline_ul {
list-style-type: none;
margin: 0;
margin-top: 10px;
padding: 0;
overflow: hidden;
background: none;
text-align: center;
}
.airline_ul li{
display: inline;
float: right;
font-size: 1.1em;
}
.airline_ul li a{
display: block;
color: white;
text-align: center;
text-decoration: none;
}
.airline_ul:nth-child(1){
margin-right: 20px;
}
.airline_ul li a:hover {
background-color: #E7E7F6;
color: #030337;
border-radius: 30px;
}
/* table 2 */
.tab2{
	width: 30%;
	height: auto;
	margin: auto;
	/* margin-top: 100px; */
}
.tab2 td{
	font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
	font-size: 1.1em;
	line-height: 40px;
	text-align:center;
	background: #65CDAA;
	width: 20%;
	/* border-radius: 5px; */
}
.tab2 td:hover{
	color: none;
	background: none;
	text-decoration: none;
	cursor: pointer;
}

/* ////// */

		</style>
	</head>
	<body>
		<div class="airline_header">
			<ul class="airline_ul">
				<li><a href="logout_handler.php">Logout</a></li>
				<li><a href="customer_homepage.php">Contact Us</a></li>
				<li><a href="customer_homepage.php">About Us</a></li>
				<li><a href="pnr.php">Print Ticket</a></li>
				<li><a href="customer_homepage.php">Dashboard</a></li>
				<li><a href="customer_homepage.php">Home</a></li>

			</ul>
		</div>
		<?php
			echo "<h2 style='margin-top:100px;text-align:center;'>Welcome ".$_SESSION['login_user']."</h2>";
			require_once('Database Connection file/mysqli_connect.php');
			$query="SELECT count(*),frequent_flier_no,mileage FROM Frequent_Flier_Details WHERE customer_id=?";
			$stmt=mysqli_prepare($dbc,$query);
			mysqli_stmt_bind_param($stmt,"s",$_SESSION['login_user']);
			mysqli_stmt_execute($stmt);
			mysqli_stmt_bind_result($stmt,$cnt,$frequent_flier_no,$mileage);
			mysqli_stmt_fetch($stmt);
			if($cnt==1)
			{
				echo "<h4 style='padding-left: 20px;text-align:center;text-transform:uppercase;'>Frequent Flier No.: ".$frequent_flier_no."&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Mileage: ".$mileage." points</h4><br>";
			}
			mysqli_stmt_close($stmt);
			mysqli_close($dbc);
		?>
		<table cellpadding="5" class="tab2">
			<tr>
				<td class="admin_func"><a href="book_tickets.php">Book Flight Tickets</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="view_booked_tickets.php">View Booked Flight Tickets</a>
				</td>
			</tr>
<tr>
				<td class="admin_func"><a href="pnr.php">Print Booked Ticket</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="cancel_booked_tickets.php">Cancel Booked Flight Tickets</a>
				</td>
			</tr>
		</table>
	</body>
</html>