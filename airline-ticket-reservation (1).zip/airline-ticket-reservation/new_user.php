<html>
	<head>
		<title>
			Create New User Account
		</title>
		<link rel="stylesheet" type="text/css" href="css/style.css"/>
		<link rel="stylesheet" href="font-awesome-4.7.0\css\font-awesome.min.css">
		<style>
			.airline_header{
	width: 100%; 
	height: 70px;
	background: #65CDAA;
	border: none;
	position: fixed;
	left: 0;
	top: 0;
}
.airline_ul {
list-style-type: none;
margin: 0;
margin-top: 10px;
padding: 0;
overflow: hidden;
background: none;
text-align: center;
}
.airline_ul li{
display: inline;
float: right;
font-size: 1.1em;
}
.airline_ul li a{
display: block;
color: white;
text-align: center;
text-decoration: none;
}
.airline_ul:nth-child(1){
margin-right: 20px;
}
.airline_ul li a:hover {
background-color: #E7E7F6;
color: #030337;
border-radius: 30px;
}

/* form */
.float_form{
width: 25%;
height: auto;
margin: auto;
margin-top: 100px;
float: none;
border: 2px solid #808080;
border-radius: 10px;
padding: 2%;
margin-left: 35%;
}
.float_form input,.float_form select,.bckbtn{
width: 100%;
height: 50px;
border: 1px solid #65CDAA;
outline: none;
margin-top: 10px;
border-radius: 5px;
padding-left: 5%;
}
.float_form input[type="radio"]{
height: 20px;
}
.float_form input[type="submit"],.bckbtn{
padding-left: 0;
font-size: 1.2em;
font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
border: none;
outline: none;
background: #65CDAA;
color: #fff;
}
/* /// */

		</style>
	</head>
	<body>
		<div class="airline_header">
			<ul class="airline_ul">
			<li><a href="login_page.php">Login</a></li>
				<li><a href="home_page.php">About Us</a></li>
				<li><a href="home_page.php">Contact Us</a></li>
				<li><a href="login_page.php">Book Tickets</a></li>
				<li><a href="home_page.php">Home</a></li>
			</ul>
		</div>
		<br>
		<form class="float_form" action="new_user_form_handler.php" method="POST" id="new_user_from">
			<h2><i class="fa fa-user-plus" aria-hidden="true"></i> CREATE NEW USER ACCOUNT</h2>
			<br>
			<table cellpadding='10'>
				<strong>ENTER LOGIN DETAILS</strong>
				<tr>
					<td>Enter a valid username  </td>
					<td><input type="text" name="username" required><br><br></td>
				</tr>
				<tr>
					<td>Enter your desired password  </td>
					<td><input type="password" name="password" required><br><br></td>
				</tr>
				<tr>
					<td>Enter your email ID</td>
					<td><input type="text" name="email" required><br><br></td>
				</tr>
			</table>
			<br>
			<table cellpadding='10'>
				<strong>ENTER CUSTOMER'S PERSONAL DETAILS</strong>
				<tr>
					<td>Enter your name  </td>
					<td><input type="text" name="name" required><br><br></td>
				</tr>
				<tr>
					<td>Enter your phone no.</td>
					<td><input type="text" name="phone_no" required><br><br></td>
				</tr>
				<tr>
					<td>Enter your address</td>
					<td><input type="text" name="address" required><br><br></td>
				</tr>
			</table>
			<br>
			<input type="submit" value="Submit" name="Submit">
			<br>
		</form>
	</body>
</html>