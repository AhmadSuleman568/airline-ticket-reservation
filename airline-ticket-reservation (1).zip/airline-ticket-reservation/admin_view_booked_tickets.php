<?php
	session_start();
?>
<html>
	<head>
		<title>
			View Booked Tickets
		</title>
		<link rel="stylesheet" type="text/css" href="css/style.css"/>
		<link rel="stylesheet" href="font-awesome-4.7.0\css\font-awesome.min.css">
		<style>
			.airline_header{
	width: 100%; 
	height: 70px;
	background: #65CDAA;
	border: none;
	position: fixed;
	left: 0;
	top: 0;
}
.airline_ul {
list-style-type: none;
margin: 0;
margin-top: 10px;
padding: 0;
overflow: hidden;
background: none;
text-align: center;
}
.airline_ul li{
display: inline;
float: right;
font-size: 1.1em;
}
.airline_ul li a{
display: block;
color: white;
text-align: center;
text-decoration: none;
}
.airline_ul:nth-child(1){
margin-right: 20px;
}
.airline_ul li a:hover {
background-color: #E7E7F6;
color: #030337;
border-radius: 30px;
}

/* form */
.float_form{
width: 25%;
height: auto;
margin: auto;
margin-top: 100px;
float: none;
border: 2px solid #808080;
border-radius: 10px;
padding: 2%;
margin-left: 35%;
}
.float_form input,.float_form select,.bckbtn{
width: 100%;
height: 50px;
border: 1px solid #65CDAA;
outline: none;
margin-top: 10px;
border-radius: 5px;
padding-left: 5%;
}
.float_form input[type="radio"]{
height: 20px;
}
.float_form input[type="submit"],.bckbtn{
padding-left: 0;
font-size: 1.2em;
font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
border: none;
outline: none;
background: #65CDAA;
color: #fff;
}
/* /// */
		</style>
	</head>
	<body>
		<div class="airline_header">
			<ul class="airline_ul">
				<li><a href="logout_handler.php">Logout</a></li>
				<li><a href="admin_homepage.php">Dashboard</a></li>
				<li><a href="admin_homepage.php">Home</a></li>
			</ul>
		</div>
		<form action="admin_view_booked_tickets_form_handler.php" method="post" class="float_form">
			<h2>VIEW LIST OF BOOKED TICKETS FOR A FLIGHT</h2>
			<div>
			<table cellpadding="5">
				<tr>
					<td class="fix_table">Enter the Flight No.</td>
					<td class="fix_table">Enter the Departure Date</td>
				</tr>
				<tr>
					<td class="fix_table"><input type="text" name="flight_no" required></td>
					<td class="fix_table"><input type="date" name="departure_date" required></td>
				</tr>
			</table>
			<br>
			<br>
			<input type="submit" value="Submit" name="Submit">
			</div>
		</form>
	</body>
</html>