<?php
	session_start();
?>
<html>
	<head>
		<title>
			Welcome Administrator
		</title>
		<link rel="stylesheet" type="text/css" href="css/style.css"/>
		<link rel="stylesheet" href="font-awesome-4.7.0\css\font-awesome.min.css">
		<style>
			.airline_header{
	width: 100%; 
	height: 70px;
	background: #65CDAA;
	border: none;
	position: fixed;
	left: 0;
	top: 0;
}
.airline_ul {
list-style-type: none;
margin: 0;
margin-top: 10px;
padding: 0;
overflow: hidden;
background: none;
text-align: center;
}
.airline_ul li{
display: inline;
float: right;
font-size: 1.1em;
}
.airline_ul li a{
display: block;
color: white;
text-align: center;
text-decoration: none;
}
.airline_ul:nth-child(1){
margin-right: 20px;
}
.airline_ul li a:hover {
background-color: #E7E7F6;
color: #030337;
border-radius: 30px;
}

.tab{
	width: 30%;
	margin: auto;
}
.tab td{
	font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
	font-size: 1.1em;
	line-height: 40px;
	text-align:center;
	background: #65CDAA;
	width: 20%;
}
.tab td:hover{
	color: none;
	background: none;
	text-decoration: none;
	cursor: pointer;
}
/* /// */

		</style>
	</head>
	<body>
		<div class="airline_header">
			<ul class="airline_ul">	
		    	<li><a href="logout_handler.php">Logout</a></li>
				<li><a href="admin_homepage.php">Dashboard</a></li>
				<li><a href="admin_homepage.php">Home</a></li>
			</ul>
		</div>
		<h2 style="margin-top: 120px;text-align:center;">Welcome Administrator!</h2>
		<table cellpadding="5" class="tab"> 
			<tr> 
				<td class="admin_func"><a href="admin_view_booked_tickets.php">View List of Booked Tickets for a Flight</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="add_flight_details.php">Add Flight Schedule Details</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="delete_flight_details.php">Delete Flight Schedule Details</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="add_jet_details.php">Add Aircrafts Details</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="activate_jet_details.php">Activate Aircraft</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="deactivate_jet_details.php">Deactivate Aircraft</a>
				</td>
			</tr>
		</table>
	</body>
</html>